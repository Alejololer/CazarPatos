class RankingAdapter {
}